"""
write_synthesized_vertebrae.py — kyphosis-apex anchored vertebrae synthesis
==========================================================================
Replacement for `_write_synthesized_vertebrae_csv()`.

Old method:  even z-spacing from FOV bounds. Wrong when FOV is asymmetric.
This method: anchor at the kyphosis apex (max cord_y in patient LPS coords =
most posterior point of cord track = anatomically C4-C5 region in cervical
lordosis), and place vertebrae outward using known cervical spacings.

Spacings (mm): C2-C3=15, C3-C4=16, C4-C5=17, C5-C6=17, C6-C7=18, C7-T1=20.

Output columns: V_idx, centroid_z_mm, centroid_x_mm, centroid_y_mm
  - centroid_z_mm: derived from apex anchor + cumulative spacing
  - centroid_x_mm: median cord_x_mm across all cord-found slices
  - centroid_y_mm: median cord_y_mm across all cord-found slices
"""
from __future__ import annotations
import csv
from pathlib import Path
from typing import Optional


# Cervical inter-vertebra spacings (centroid to centroid), in mm.
# Indexed by superior level: SPACING_MM[level] = distance from level to the
# next inferior level. C4-C5 spacing is the distance C4 → C5, etc.
SPACING_MM = {
    ('C2', 'C3'): 15.0,
    ('C3', 'C4'): 16.0,
    ('C4', 'C5'): 17.0,
    ('C5', 'C6'): 17.0,
    ('C6', 'C7'): 18.0,
    ('C7', 'T1'): 20.0,
}

# Anatomic order, superior to inferior
LEVEL_ORDER = ['C2', 'C3', 'C4', 'C5', 'C6', 'C7', 'T1']


def _median(values: list[float]) -> float:
    """Median without numpy dependency."""
    s = sorted(values)
    n = len(s)
    if n == 0:
        return 0.0
    if n % 2 == 1:
        return s[n // 2]
    return (s[n // 2 - 1] + s[n // 2]) / 2


def _write_synthesized_vertebrae_csv(
    cord_canal_csv: str | Path,
    out_csv: str | Path,
) -> Path:
    """Build vertebrae.csv anchored at the kyphosis apex.

    Steps:
      1. Read cord_canal_per_slice.csv. Use only rows where cord_found=True
         AND cord_confidence != INVALID.
      2. Find the z-position of maximum cord_y_mm. In LPS patient coords
         posterior = +y, so max cord_y = the most posterior cord point =
         kyphosis apex = anatomically the C4-C5 disc level.
      3. Anchor C4-C5 disc midpoint at apex_z. Place C4 superior by half the
         C4-C5 spacing, C5 inferior by half. Walk outward from there using
         SPACING_MM.
      4. Centroid x and y are taken from the median cord position across all
         cord-found slices (the cord track sits posterior to the vertebra
         column by a near-constant offset, so the cord median is a stable
         x,y reference even though the y is the cord y rather than the
         vertebra body y — downstream code uses these only as an anatomic
         anchor for matching axial slices to levels).

    Args:
      cord_canal_csv: path to cord_canal_per_slice.csv (output of measure_spine.py)
      out_csv:        path to write vertebrae.csv

    Returns:
      Path to the written vertebrae.csv
    """
    cord_canal_csv = Path(cord_canal_csv)
    out_csv = Path(out_csv)

    # Step 1: load cord track from cord-found rows only
    track = []
    high_track = []
    with open(cord_canal_csv, newline='') as f:
        for r in csv.DictReader(f):
            if r.get('cord_found', 'False') != 'True':
                continue
            conf = r.get('cord_confidence', '')
            if conf == 'INVALID':
                continue
            try:
                z = float(r['z_mm'])
                cx = float(r['cord_x_mm'])
                cy = float(r['cord_y_mm'])
            except (KeyError, ValueError, TypeError):
                continue
            point = {'z': z, 'cx': cx, 'cy': cy, 'conf': conf}
            track.append(point)
            if conf == 'HIGH':
                high_track.append(point)

    if not track:
        raise ValueError(
            f'No cord-found rows in {cord_canal_csv} — cannot synthesize '
            f'vertebrae. Pipeline upstream produced no usable measurements.'
        )

    # Step 2: kyphosis apex = z position of maximum cord_y_mm
    # (most posterior cord point in LPS patient coords).
    # Use HIGH-confidence rows only when available — LOW-confidence cord_y
    # values can include large outliers from the detector locking onto
    # non-cord structures, which would pull the apex to an anatomically
    # impossible location.
    # Also restrict to the central portion of the cord track: the cervical
    # apex sits anatomically in the middle of the cervical FOV (around C4-C5),
    # not at the top of the stack (skull base) or the bottom (cervicothoracic
    # junction). Drop EDGE_MARGIN_MM from each end of the z range when picking
    # the apex.
    EDGE_MARGIN_MM = 25.0
    apex_pool = high_track if high_track else track
    if len(apex_pool) >= 3:
        z_lo = min(t['z'] for t in apex_pool)
        z_hi = max(t['z'] for t in apex_pool)
        z_span = z_hi - z_lo
        # If the stack is too short to apply the full margin, use a smaller one
        margin = min(EDGE_MARGIN_MM, z_span / 4)
        central = [t for t in apex_pool
                   if z_lo + margin <= t['z'] <= z_hi - margin]
        if central:
            apex_pool = central
    apex_row = max(apex_pool, key=lambda t: t['cy'])
    apex_z = apex_row['z']

    # Step 3: place vertebrae outward from C4-C5 disc at apex_z
    # C4-C5 disc midpoint = apex_z
    # C4 centroid_z = apex_z + (C4-C5 spacing) / 2  (superior)
    # C5 centroid_z = apex_z - (C4-C5 spacing) / 2  (inferior)
    c45 = SPACING_MM[('C4', 'C5')]
    z_of = {
        'C4': apex_z + c45 / 2,
        'C5': apex_z - c45 / 2,
    }
    # Walk superior from C4
    z_of['C3'] = z_of['C4'] + SPACING_MM[('C3', 'C4')]
    z_of['C2'] = z_of['C3'] + SPACING_MM[('C2', 'C3')]
    # Walk inferior from C5
    z_of['C6'] = z_of['C5'] - SPACING_MM[('C5', 'C6')]
    z_of['C7'] = z_of['C6'] - SPACING_MM[('C6', 'C7')]
    z_of['T1'] = z_of['C7'] - SPACING_MM[('C7', 'T1')]

    # Step 5: median cord position for centroid_x/centroid_y.
    # Use HIGH-confidence rows when available — same reason as apex selection.
    median_pool = high_track if high_track else track
    med_cx = _median([t['cx'] for t in median_pool])
    med_cy = _median([t['cy'] for t in median_pool])

    # Build output rows in superior-to-inferior order (V1 = C2, V7 = T1)
    rows = []
    for i, level in enumerate(LEVEL_ORDER, start=1):
        rows.append({
            'V_idx':          i,
            'centroid_z_mm':  round(z_of[level], 3),
            'centroid_x_mm':  round(med_cx, 3),
            'centroid_y_mm':  round(med_cy, 3),
        })

    # Write CSV
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    with open(out_csv, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['V_idx', 'centroid_z_mm',
                                          'centroid_x_mm', 'centroid_y_mm'])
        w.writeheader()
        for r in rows:
            w.writerow(r)

    # Diagnostic print
    print(f'Kyphosis apex at z={apex_z:+.2f}mm (max cord_y={apex_row["cy"]:+.2f})')
    print(f'Cord track median position: x={med_cx:+.2f}, y={med_cy:+.2f}')
    print(f'Synthesized vertebrae (V_idx → level → z):')
    for i, level in enumerate(LEVEL_ORDER, start=1):
        print(f'  V{i} = {level}: z = {z_of[level]:+.2f} mm')
    print(f'Wrote {out_csv}')

    return out_csv


if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser(
        description='Synthesize vertebrae.csv anchored at kyphosis apex'
    )
    ap.add_argument('cord_canal_csv',
                    help='cord_canal_per_slice.csv from measure_spine.py')
    ap.add_argument('--out', default='vertebrae.csv',
                    help='path to output vertebrae CSV (default: ./vertebrae.csv)')
    args = ap.parse_args()
    _write_synthesized_vertebrae_csv(args.cord_canal_csv, args.out)
