"""
example_run.py — minimal example of using the pipeline programmatically
========================================================================

Usage:
    python example_run.py /path/to/scan.zip
"""
import sys
import json
from cspine_k7_pipeline import run_pipeline


def main(zip_path: str):
    result = run_pipeline(zip_path, out_dir='example_output', save_files=True)

    print(f"Status: {result['status']}")
    if result['status'] != 'OK':
        print(f"Reason: {result['status_reason']}")
        return 1

    print(f"Axial slices analyzed:  {result['n_axial_slices']}")
    print(f"Sag slices analyzed:    {result['n_sagittal_slices']}")
    print(f"Total markers placed:   {result['n_markers']}")
    print(f"Marker counts by type:")
    for t, n in result['marker_counts_by_type'].items():
        print(f"  {t:<25} {n}")

    print(f"\nPer-level severity (superior to inferior):")
    print(f"  {'Level':<5} {'z_mm':>7} {'n':>3}  {'Severity':<12} {'csf_min_mm':>10}")
    for L in result['per_level']:
        csf = L['worst_csf_space_min_mm']
        csf_str = f'{csf:.2f}' if csf is not None else 'n/a'
        print(f"  {L['level']:<5} {L['level_z_mm']:>+6.1f}  {L['n_slices']:>3}  "
              f"{L['worst_severity']:<12} {csf_str:>10}")

    print(f"\nOutputs in: example_output/")
    return 0


if __name__ == '__main__':
    if len(sys.argv) != 2:
        print('Usage: python example_run.py /path/to/scan.zip')
        sys.exit(2)
    sys.exit(main(sys.argv[1]))
