"""
run_pipeline.py — Top-level cervical spine measurement pipeline
================================================================

End-to-end driver. Takes a DICOM zip (or directory) and produces:
  - markers.json            k7 marker list (cord_center, csf_*, canal_wall_*, cord_centerline)
  - per_slice.json          per-slice cord/canal distances
  - vertebrae.json          synthesized vertebrae from kyphosis apex
  - per_level.json          per-level worst-severity classification
  - pipeline_result.json    everything bundled, plus provenance

Usage:
    python -m cspine_k7_pipeline.run_pipeline /path/to/scan.zip --out-dir results/

Programmatic:
    from cspine_k7_pipeline.run_pipeline import run_pipeline
    result = run_pipeline('/path/to/scan.zip', out_dir='results/')

Stages:
    1. lzw.walk      → manifest of DICOM files
    2. data_extract  → series identification
    3. cspine_k7     → k-space marker placement (vendor-neutral)
    4. spine_measurements.markers_to_slice_measurements → per-slice distances
    5. cord_track → kyphosis apex → synthesized vertebrae
    6. spine_measurements.classify_severity + aggregate_levels → per-level

The pipeline produces severity grades from physical millimeter measurements
without intensity thresholds anywhere in the measurement path.
"""
from __future__ import annotations
import argparse
import csv
import json
import sys
from pathlib import Path
from typing import Optional, Any

# Package-relative imports
from . import lzw
from . import data_extract
from .analyzers._base import load_volume
from .analyzers._spine_common import select_best_t2_axsag
from .analyzers.cspine_k7 import analyze_cspine_k7
from .spine_measurements import (
    markers_to_slice_measurements,
    classify_severity,
    aggregate_levels,
)
from .write_synthesized_vertebrae import _write_synthesized_vertebrae_csv


def _cord_track_from_markers(markers: list) -> list[dict]:
    """Extract a cord-track list (z, cord_x, cord_y) from k7 cord_center
    markers, suitable as input for the kyphosis-apex vertebra synthesizer.

    Returns a list of dicts with keys: z_mm, cord_x_mm, cord_y_mm, confidence.
    Sorted superior to inferior (descending z).
    """
    track = []
    for m in markers:
        if m.get('type') != 'cord_center':
            continue
        xyz = m.get('xyz_mm')
        if xyz is None or len(xyz) < 3:
            continue
        track.append({
            'z_mm':       float(xyz[2]),
            'cord_x_mm':  float(xyz[0]),
            'cord_y_mm':  float(xyz[1]),
            'confidence': float(m.get('confidence', 0.0)),
        })
    track.sort(key=lambda t: -t['z_mm'])
    return track


def synthesize_vertebrae_from_markers(
    markers: list,
    out_csv: Optional[Path] = None,
) -> list[dict]:
    """Run the kyphosis-apex vertebra synthesizer directly on k7 cord_center
    markers (no need for the cord_canal_per_slice.csv intermediate).

    The synthesizer module reads a CSV by design — we write a tiny temporary
    CSV in the same column schema, then call its public function.
    """
    import tempfile
    track = _cord_track_from_markers(markers)
    if not track:
        return []

    # Write a minimal CSV in the schema write_synthesized_vertebrae expects:
    #   cord_found, cord_confidence, z_mm, cord_x_mm, cord_y_mm
    # Apply the same HIGH/LOW labeling rule as the rest of the pipeline:
    # confidence >= 0.5 → HIGH, otherwise LOW.
    with tempfile.NamedTemporaryFile('w', suffix='.csv', delete=False, newline='') as tf:
        tmp_path = Path(tf.name)
        w = csv.DictWriter(tf, fieldnames=[
            'cord_found', 'cord_confidence', 'z_mm', 'cord_x_mm', 'cord_y_mm',
        ])
        w.writeheader()
        for p in track:
            w.writerow({
                'cord_found':      'True',
                'cord_confidence': 'HIGH' if p['confidence'] >= 0.5 else 'LOW',
                'z_mm':            p['z_mm'],
                'cord_x_mm':       p['cord_x_mm'],
                'cord_y_mm':       p['cord_y_mm'],
            })

    target = out_csv if out_csv is not None else (tmp_path.parent / 'vertebrae.csv')
    _write_synthesized_vertebrae_csv(tmp_path, target)

    # Read the vertebrae back as a list of dicts
    vertebrae = []
    with open(target) as f:
        for r in csv.DictReader(f):
            vertebrae.append({
                'V_idx':         int(r['V_idx']),
                'centroid_z_mm': float(r['centroid_z_mm']),
                'centroid_x_mm': float(r['centroid_x_mm']),
                'centroid_y_mm': float(r['centroid_y_mm']),
            })

    # Apply cervical level names V1=C2 .. V7=T1
    LEVEL_NAMES = ['C2', 'C3', 'C4', 'C5', 'C6', 'C7', 'T1']
    for i, v in enumerate(vertebrae):
        if i < len(LEVEL_NAMES):
            v['level'] = LEVEL_NAMES[i]

    tmp_path.unlink(missing_ok=True)
    return vertebrae


def run_pipeline(
    zip_or_dir: str | Path,
    out_dir: str | Path = '.',
    save_files: bool = True,
    work_dir: Optional[str | Path] = None,
) -> dict:
    """End-to-end pipeline. Returns a single result dict.

    Args:
      zip_or_dir:  path to a DICOM zip, directory, or single file
      out_dir:     where to write JSON outputs (if save_files=True)
      save_files:  write JSON outputs to disk (default True)
      work_dir:    temp extraction directory for lzw (default: auto)

    Returns:
      Result dict with keys:
        algorithm_version, body_part_label, status, status_reason,
        n_axial_slices, n_sagittal_slices, n_markers,
        markers, per_slice, vertebrae, per_level,
        provenance
    """
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Stage 1: walk
    manifest = lzw.walk(
        str(zip_or_dir),
        work_dir=str(work_dir) if work_dir is not None else None,
        write_manifest=False,
    )

    # Stage 2: extract series metadata
    extract_result = data_extract.run(manifest, write_json=False)

    # Build series-list shape expected by select_best_t2_axsag.
    # data_extract.result.series is a list of SeriesFacts records.
    # The selector needs 'orientation' (AX/SAG/COR) and 'sample_ds' (a
    # pydicom Dataset) — neither lives in SeriesFacts directly, so we
    # derive them from the slice list.
    import pydicom
    from .analyzers._base import classify_orientation

    series_list = []
    for s in extract_result.series:
        slice_records = [sl for sl in extract_result.slices
                         if sl.series_instance_uid == s.series_instance_uid
                         and sl.status == 'OK']
        if not slice_records:
            continue

        # Read one DICOM dataset as the series sample
        try:
            sample_ds = pydicom.dcmread(slice_records[0].extracted_path,
                                         stop_before_pixels=True, force=True)
        except Exception:
            continue

        # Orientation classification
        if s.is_axial_stack:
            orientation = 'AX'
        elif s.is_sagittal_stack:
            orientation = 'SAG'
        elif s.is_coronal_stack:
            orientation = 'COR'
        else:
            # Fall back to per-slice IOP classification
            try:
                iop = list(sample_ds.ImageOrientationPatient)
                orientation = classify_orientation(iop)
            except Exception:
                orientation = 'UNKNOWN'

        series_list.append({
            'series_description': s.series_description,
            'series_uid':         s.series_instance_uid,
            'modality':           s.modality,
            'n_slices':           s.n_slices_imaging,
            'is_axial_stack':     s.is_axial_stack,
            'is_sagittal_stack':  s.is_sagittal_stack,
            'orientation':        orientation,
            'sample_ds':          sample_ds,
            'files':              [sl.extracted_path for sl in slice_records],
        })

    ax_t2, sag_t2 = select_best_t2_axsag(series_list)
    if ax_t2 is None or sag_t2 is None:
        result = {
            'algorithm_version': 'k7',
            'body_part_label':   'cervical_spine_k7',
            'status':            'INSUFFICIENT_DATA',
            'status_reason':     ('axial T2 not found' if ax_t2 is None
                                  else 'sagittal T2 not found'),
            'series_available':  [s['series_description'] for s in series_list],
        }
        if save_files:
            (out_dir / 'pipeline_result.json').write_text(json.dumps(result, indent=2))
        return result

    # Stage 3: load volumes, run k7
    ax_items = load_volume(ax_t2['files'])
    sag_items = load_volume(sag_t2['files'])
    ax_items_sorted = sorted(ax_items, key=lambda s: s['ipp'][2])

    k7_result = analyze_cspine_k7(ax_items_sorted, sag_items)
    markers = k7_result['markers']

    # Stage 4: per-slice measurements
    per_slice = markers_to_slice_measurements(markers)
    per_slice_classified = classify_severity(per_slice)

    # Stage 5: vertebrae from kyphosis apex
    vert_path = out_dir / 'vertebrae.csv' if save_files else None
    vertebrae = synthesize_vertebrae_from_markers(markers, out_csv=vert_path)

    # Stage 6: per-level aggregation
    per_level = aggregate_levels(per_slice_classified, vertebrae)

    # Bundle result
    result = {
        'algorithm_version':  'k7',
        'body_part_label':    'cervical_spine_k7',
        'status':             'OK',
        'status_reason':      '',
        'n_axial_slices':     k7_result['n_axial_slices'],
        'n_sagittal_slices':  k7_result['n_sagittal_slices'],
        'n_markers':          k7_result['n_markers'],
        'marker_counts_by_type': k7_result.get('marker_counts_by_type', {}),
        'series_used': {
            'axial_t2':    {'series_description': ax_t2['series_description'],
                            'n_slices': ax_t2['n_slices'],
                            'series_uid': ax_t2['series_uid']},
            'sagittal_t2': {'series_description': sag_t2['series_description'],
                            'n_slices': sag_t2['n_slices'],
                            'series_uid': sag_t2['series_uid']},
        },
        'markers':            markers,
        'per_slice':          per_slice_classified,
        'vertebrae':          vertebrae,
        'per_level':          per_level,
    }

    if save_files:
        (out_dir / 'markers.json').write_text(json.dumps(markers, indent=2))
        (out_dir / 'per_slice.json').write_text(json.dumps(per_slice_classified, indent=2))
        (out_dir / 'vertebrae.json').write_text(json.dumps(vertebrae, indent=2))
        (out_dir / 'per_level.json').write_text(json.dumps(per_level, indent=2))
        (out_dir / 'pipeline_result.json').write_text(json.dumps(result, indent=2))

    return result


# ── CLI ─────────────────────────────────────────────────────────────────────

def _main():
    ap = argparse.ArgumentParser(
        description='Cervical spine k-space measurement pipeline (k7)'
    )
    ap.add_argument('input', help='DICOM zip, directory, or single file')
    ap.add_argument('--out-dir', default='.', help='output directory for JSON results')
    ap.add_argument('--work-dir', default=None, help='extraction work directory')
    ap.add_argument('--quiet', action='store_true', help='suppress progress output')
    args = ap.parse_args()

    if not args.quiet:
        print(f'Pipeline input: {args.input}')

    result = run_pipeline(args.input, out_dir=args.out_dir,
                          save_files=True, work_dir=args.work_dir)

    if not args.quiet:
        print(f'\nStatus: {result["status"]}')
        if result['status'] != 'OK':
            print(f'Reason: {result["status_reason"]}')
            sys.exit(1)
        print(f'Axial slices: {result["n_axial_slices"]}')
        print(f'Markers placed: {result["n_markers"]}')
        print(f'Per-slice measurements: {len(result["per_slice"])}')
        print(f'\nPer-level severity:')
        for lev in result['per_level']:
            print(f'  {lev["level"]:>4}  (z={lev["level_z_mm"]:+.1f})  '
                  f'n={lev["n_slices"]:>2}  worst={lev["worst_severity"]:<10}  '
                  f'csf_min={lev["worst_csf_space_min_mm"]}')
        print(f'\nOutputs written to: {args.out_dir}')


if __name__ == '__main__':
    _main()
