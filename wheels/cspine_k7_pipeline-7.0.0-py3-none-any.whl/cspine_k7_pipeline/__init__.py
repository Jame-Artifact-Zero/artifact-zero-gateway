"""
cspine_k7_pipeline
==================

K-space cervical spine measurement pipeline. Vendor-neutral by construction.

Public API:

    from cspine_k7_pipeline import run_pipeline
    result = run_pipeline('/path/to/scan.zip', out_dir='results/')

    # Lower-level entry points:
    from cspine_k7_pipeline.analyzers.cspine_k7 import analyze_cspine_k7
    from cspine_k7_pipeline.spine_measurements import (
        markers_to_slice_measurements,
        classify_severity,
        aggregate_levels,
    )
"""
from .run_pipeline import run_pipeline
from .spine_measurements import (
    markers_to_slice_measurements,
    classify_severity,
    aggregate_levels,
    SEVERITY_ORDER,
    SEVERITY_THRESHOLDS_MM,
)

__version__ = '7.0.0'
__all__ = [
    'run_pipeline',
    'markers_to_slice_measurements',
    'classify_severity',
    'aggregate_levels',
    'SEVERITY_ORDER',
    'SEVERITY_THRESHOLDS_MM',
]
