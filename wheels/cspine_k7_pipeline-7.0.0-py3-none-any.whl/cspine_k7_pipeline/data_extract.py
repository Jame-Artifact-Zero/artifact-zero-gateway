"""
data_extract.py — Pixel-Level Data Extraction
==============================================
The layer between the manifest (LZW output) and the measurement code.

Input:  A Manifest from lzw.walk(). The manifest tells us which FileEntries
        are imaging files, what series they belong to, and where the bytes
        live on disk.

Output: Two tables of pixel-level facts.

  SliceFacts   — one row per imaging file. Records what we observed when we
                 opened the pixel array: shape, intensity stats, k-space
                 band energies, patient-coordinate transforms, and the
                 intensity-band image-space partition.

  SeriesFacts  — one row per series. Aggregates SliceFacts by series with
                 stack-level facts: z-coordinate range, slice count, mean
                 intensity stats, dominant orientation.

The contract:

  Every column is an OBSERVED fact about the pixel data. No claims about
  what tissue any pixel represents. No template matching. No clinical
  interpretation. Just measurements that downstream code can reason about.

  Facts that span slices (a track, a cord centerline, a measurement) are
  NOT in scope. Those are downstream of this layer.

Author: Jame Houghton / Artifact Zero, May 2026
Schema version: 1.0
"""
from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional

import numpy as np
import pydicom
from scipy.ndimage import label, center_of_mass

# Reuse lzw's manifest schema. Support both package use (relative) and
# standalone-script use (absolute).
try:
    from . import lzw
    from .lzw import (
        Manifest, FileEntry, SeriesEntry,
        IMAGING_MODALITIES,
    )
except ImportError:
    import lzw
    from lzw import (
        Manifest, FileEntry, SeriesEntry,
        IMAGING_MODALITIES,
    )

log = logging.getLogger(__name__)

DATA_EXTRACT_VERSION = "1.0"


# ════════════════════════════════════════════════════════════════════════════
# DATA CLASSES — extraction schema, version 1.0
# ════════════════════════════════════════════════════════════════════════════

@dataclass
class IntensityStats:
    """Per-slice intensity statistics. All in raw pixel values, no rescaling."""
    min:    float = 0.0
    max:    float = 0.0
    mean:   float = 0.0
    median: float = 0.0
    std:    float = 0.0
    p05:    float = 0.0
    p25:    float = 0.0
    p50:    float = 0.0
    p75:    float = 0.0
    p90:    float = 0.0
    p95:    float = 0.0
    p99:    float = 0.0


@dataclass
class KSpaceBandFacts:
    """K-space energy per anatomy band (by wavelength in mm).

    Computed by FFT on (img - img.mean()). Band masks use only the unique
    half of k-space to avoid double-counting conjugate-symmetric pairs.

    Band boundaries (mm):
      noise_subpix    : < 0.6
      noise_voxel     : 0.6 - 1.5
      fine_anatomy    : 1.5 - 4.0
      cord_scale      : 4.0 - 10.0
      vertebra_scale  : 10.0 - 25.0
      body_shape      : >= 25.0
    """
    total_energy_ex_dc: float = 0.0
    e_noise_subpix:     float = 0.0
    e_noise_voxel:      float = 0.0
    e_fine_anatomy:     float = 0.0
    e_cord_scale:       float = 0.0
    e_vertebra_scale:   float = 0.0
    e_body_shape:       float = 0.0


@dataclass
class GradientFacts:
    """Per-slice gradient summary.

    smooth = gaussian_filter(img, sigma=2.0)
    gmag   = sqrt(d/dx² + d/dy²) of smooth
    """
    gmag_mean:       float = 0.0
    gmag_p95:        float = 0.0
    gmag_p99:        float = 0.0
    peak_angle_deg:  float = 0.0   # dominant direction of strong (>p95) gradients
    n_strong:        int   = 0     # number of pixels with gmag > p95


@dataclass
class BandObjectCounts:
    """How many connected-component objects (>=1 mm²) live in each band."""
    n_dark:        int = 0
    n_medium:      int = 0
    n_bright:      int = 0
    n_very_bright: int = 0
    biggest_dark_mm2:        float = 0.0
    biggest_medium_mm2:      float = 0.0
    biggest_bright_mm2:      float = 0.0
    biggest_very_bright_mm2: float = 0.0


@dataclass
class GeometryFacts:
    """Slice geometry derived from DICOM tags. Patient coords are absolute."""
    rows: int = 0
    cols: int = 0
    pixel_spacing_row_mm: float = 0.0
    pixel_spacing_col_mm: float = 0.0
    slice_thickness_mm:   Optional[float] = None
    # Patient-coordinate position of the slice TOP-LEFT pixel
    ipp_x: float = 0.0
    ipp_y: float = 0.0
    ipp_z: float = 0.0
    # Patient-coordinate direction vectors (from IOP)
    row_dir: list[float] = field(default_factory=list)  # +col axis dir
    col_dir: list[float] = field(default_factory=list)  # +row axis dir
    # Patient-coordinate position of the slice CENTER pixel
    center_xyz: list[float] = field(default_factory=list)
    # Image-pixel of patient (0,0,0) — if it falls inside the slice, else None
    pc_pixel_row: Optional[float] = None
    pc_pixel_col: Optional[float] = None
    # Orientation tilt: how far from purely axial / sagittal / coronal
    # Reported as |col_dir.z| (1=axial, 0=coronal or sagittal)
    orientation_axial_alignment:    float = 0.0  # |col_dir·z_hat|
    orientation_sagittal_alignment: float = 0.0  # |row_dir·x_hat|


@dataclass
class SliceFacts:
    """One row per imaging file. Pixel-level facts about that slice."""
    # Identity
    extracted_path:     str = ""
    sop_instance_uid:   str = ""
    series_instance_uid: str = ""
    series_description:  Optional[str] = None
    modality:           Optional[str] = None
    instance_number:    Optional[int] = None
    z_position_mm:      Optional[float] = None    # ipp[2]
    # Status
    status:             str = "OK"   # OK | PIXEL_READ_FAILED | NOT_IMAGING |
                                      # MISSING_GEOMETRY | UNUSABLE_SHAPE
    status_detail:      str = ""
    # Facts (only populated when status == OK)
    geometry:           Optional[GeometryFacts] = None
    intensity:          Optional[IntensityStats] = None
    kspace:             Optional[KSpaceBandFacts] = None
    gradient:           Optional[GradientFacts] = None
    band_objects:       Optional[BandObjectCounts] = None


@dataclass
class SeriesFacts:
    """One row per series. Aggregates SliceFacts."""
    series_instance_uid: str = ""
    series_description:  Optional[str] = None
    modality:            Optional[str] = None
    n_slices_imaging:    int = 0
    n_slices_unusable:   int = 0
    rows: Optional[int] = None
    cols: Optional[int] = None
    pixel_spacing_mm:    Optional[float] = None
    # Z range (slice positions in patient coords)
    z_min: Optional[float] = None
    z_max: Optional[float] = None
    z_span_mm: Optional[float] = None
    # Stack-level intensity stats: median of per-slice p50 etc.
    stack_p50_median: Optional[float] = None
    stack_p90_median: Optional[float] = None
    # Stack-level orientation
    is_axial_stack:    bool = False
    is_sagittal_stack: bool = False
    is_coronal_stack:  bool = False


@dataclass
class ExtractionResult:
    """Top-level output of data_extract.run()."""
    data_extract_version: str = DATA_EXTRACT_VERSION
    work_dir: str = ""
    n_slice_facts: int = 0
    n_series_facts: int = 0
    n_slices_unusable: int = 0
    slices: list[SliceFacts] = field(default_factory=list)
    series: list[SeriesFacts] = field(default_factory=list)
    elapsed_seconds: float = 0.0


# ════════════════════════════════════════════════════════════════════════════
# CORE PER-SLICE EXTRACTION
# ════════════════════════════════════════════════════════════════════════════

# Above this pixel count, FFT/gradient/labeling work is downsampled.
# Chosen so 1024x1024 (~1M) runs full-resolution and 2200x2200 (~5M) is
# downsampled by stride=3.
_LARGE_IMAGE_THRESHOLD = 1_000_000


def _maybe_downsample(img: np.ndarray, ps_mm: float) -> tuple[np.ndarray, float, int]:
    """Return (img_or_downsampled, effective_ps_mm, stride). stride=1 means no change."""
    H, W = img.shape
    total = H * W
    if total <= _LARGE_IMAGE_THRESHOLD:
        return img, ps_mm, 1
    stride = int(np.ceil(np.sqrt(total / _LARGE_IMAGE_THRESHOLD)))
    return img[::stride, ::stride], ps_mm * stride, stride


def _compute_intensity_stats(img: np.ndarray) -> IntensityStats:
    return IntensityStats(
        min=float(img.min()),
        max=float(img.max()),
        mean=float(img.mean()),
        median=float(np.median(img)),
        std=float(img.std()),
        p05=float(np.percentile(img, 5)),
        p25=float(np.percentile(img, 25)),
        p50=float(np.percentile(img, 50)),
        p75=float(np.percentile(img, 75)),
        p90=float(np.percentile(img, 90)),
        p95=float(np.percentile(img, 95)),
        p99=float(np.percentile(img, 99)),
    )


def _compute_kspace_bands(img: np.ndarray, ps_mm: float) -> KSpaceBandFacts:
    """K-space band energies. ps_mm is the smaller of row/col pixel spacing.
    Big images are downsampled before FFT to keep runtime bounded."""
    img_ds, ps_eff, _ = _maybe_downsample(img, ps_mm)
    H, W = img_ds.shape
    F = np.fft.fft2(img_ds - img_ds.mean())
    F_shift = np.fft.fftshift(F)
    mag = np.abs(F_shift)
    cy, cx = H // 2, W // 2
    yy, xx = np.indices(mag.shape)
    dist = np.hypot(yy - cy, xx - cx)
    half_mask = (yy > cy) | ((yy == cy) & (xx >= cx))

    total_ex_dc = float(mag.sum() - mag[cy, cx])

    # Wavelength in mm for each k-space pixel.
    # wavelength_px = N / max(dist, 0.5); we use N = min(H, W)
    N = min(H, W)
    with np.errstate(divide='ignore'):
        wl_mm = np.where(dist > 0, (N / np.maximum(dist, 0.5)) * ps_eff, np.inf)

    def band_energy(lo_mm, hi_mm):
        m = (wl_mm >= lo_mm) & (wl_mm < hi_mm) & half_mask
        return float(mag[m].sum())

    return KSpaceBandFacts(
        total_energy_ex_dc=total_ex_dc,
        e_noise_subpix=band_energy(0.0, 0.6),
        e_noise_voxel=band_energy(0.6, 1.5),
        e_fine_anatomy=band_energy(1.5, 4.0),
        e_cord_scale=band_energy(4.0, 10.0),
        e_vertebra_scale=band_energy(10.0, 25.0),
        e_body_shape=band_energy(25.0, 1e9),
    )


def _compute_gradient_facts(img: np.ndarray) -> GradientFacts:
    """Smooth and compute gradient magnitude. Returns summary stats.
    Big images are downsampled to keep gaussian/sobel runtime bounded."""
    from scipy.ndimage import gaussian_filter, sobel
    img_ds, _, _ = _maybe_downsample(img, 1.0)
    smooth = gaussian_filter(img_ds, sigma=2.0)
    gx = sobel(smooth, axis=1)
    gy = sobel(smooth, axis=0)
    gmag = np.hypot(gx, gy)
    p95 = float(np.percentile(gmag, 95))
    p99 = float(np.percentile(gmag, 99))
    strong = gmag > p95
    n_strong = int(strong.sum())
    if n_strong > 0:
        gangle = np.arctan2(gy, gx)
        angles_mod = (np.degrees(gangle[strong]) % 180)
        hist, edges = np.histogram(angles_mod, bins=12, range=(0, 180))
        peak_bin = int(np.argmax(hist))
        peak_angle = (edges[peak_bin] + edges[peak_bin + 1]) / 2
    else:
        peak_angle = 0.0
    return GradientFacts(
        gmag_mean=float(gmag.mean()),
        gmag_p95=p95,
        gmag_p99=p99,
        peak_angle_deg=float(peak_angle),
        n_strong=n_strong,
    )


def _compute_band_object_counts(
    img: np.ndarray, intensity: IntensityStats, ps_mm: float,
    min_area_mm2: float = 1.0,
) -> BandObjectCounts:
    """Connected-component object counts per intensity band.

    On images larger than 1M pixels we downsample by integer stride before
    band labeling. This keeps the runtime bounded for x-ray and large CT.
    The effective pixel spacing changes by the stride factor, so areas are
    still reported in mm² correctly.
    """
    bc = BandObjectCounts()
    p25, p50, p75, p90 = intensity.p25, intensity.p50, intensity.p75, intensity.p90

    # Downsample very large images via the shared helper.
    img_ds, ps_eff, _ = _maybe_downsample(img, ps_mm)

    masks = {
        'dark':        (img_ds >= p25) & (img_ds < p50),
        'medium':      (img_ds >= p50) & (img_ds < p75),
        'bright':      (img_ds >= p75) & (img_ds < p90),
        'very_bright': (img_ds >= p90),
    }
    min_pix = max(1, int(min_area_mm2 / (ps_eff * ps_eff)))
    for name, m in masks.items():
        lbls, n = label(m)
        if n == 0:
            continue
        # Vector size-of-each-label via bincount — much faster than per-label loop
        sizes = np.bincount(lbls.ravel())
        # sizes[0] is background; skip it
        if len(sizes) > 1:
            real_sizes = sizes[1:]
            kept = real_sizes[real_sizes >= min_pix]
            count = int(len(kept))
            biggest_size = int(real_sizes.max()) if len(real_sizes) else 0
        else:
            count = 0
            biggest_size = 0
        biggest_mm2 = biggest_size * ps_eff * ps_eff
        if name == 'dark':
            bc.n_dark = count
            bc.biggest_dark_mm2 = float(biggest_mm2)
        elif name == 'medium':
            bc.n_medium = count
            bc.biggest_medium_mm2 = float(biggest_mm2)
        elif name == 'bright':
            bc.n_bright = count
            bc.biggest_bright_mm2 = float(biggest_mm2)
        elif name == 'very_bright':
            bc.n_very_bright = count
            bc.biggest_very_bright_mm2 = float(biggest_mm2)
    return bc


def _compute_geometry_facts(ds: pydicom.Dataset, img_shape: tuple) -> GeometryFacts:
    """Slice geometry from DICOM tags. ps[0]=row spacing, ps[1]=col spacing."""
    H, W = img_shape
    g = GeometryFacts(rows=H, cols=W)

    ps_attr = getattr(ds, 'PixelSpacing', None)
    if ps_attr is not None and len(ps_attr) >= 2:
        g.pixel_spacing_row_mm = float(ps_attr[0])
        g.pixel_spacing_col_mm = float(ps_attr[1])
    elif ps_attr is not None and len(ps_attr) == 1:
        g.pixel_spacing_row_mm = float(ps_attr[0])
        g.pixel_spacing_col_mm = float(ps_attr[0])
    else:
        ips = getattr(ds, 'ImagerPixelSpacing', None)
        if ips is not None and len(ips) >= 2:
            g.pixel_spacing_row_mm = float(ips[0])
            g.pixel_spacing_col_mm = float(ips[1])

    g.slice_thickness_mm = (float(ds.SliceThickness)
                             if hasattr(ds, 'SliceThickness') else None)

    ipp = getattr(ds, 'ImagePositionPatient', None)
    iop = getattr(ds, 'ImageOrientationPatient', None)
    if ipp is None or iop is None:
        return g  # Cannot fill patient-coord fields without IPP/IOP

    g.ipp_x, g.ipp_y, g.ipp_z = float(ipp[0]), float(ipp[1]), float(ipp[2])
    row_dir = [float(x) for x in iop[0:3]]
    col_dir = [float(x) for x in iop[3:6]]
    g.row_dir = row_dir
    g.col_dir = col_dir

    # Center pixel patient coords
    cr, cc = H / 2, W / 2
    cx = (g.ipp_x + cc * g.pixel_spacing_col_mm * row_dir[0]
                  + cr * g.pixel_spacing_row_mm * col_dir[0])
    cy = (g.ipp_y + cc * g.pixel_spacing_col_mm * row_dir[1]
                  + cr * g.pixel_spacing_row_mm * col_dir[1])
    cz = (g.ipp_z + cc * g.pixel_spacing_col_mm * row_dir[2]
                  + cr * g.pixel_spacing_row_mm * col_dir[2])
    g.center_xyz = [cx, cy, cz]

    # Image-pixel of patient (0,0,0). Solve:
    #   ipp + j * ps_c * row_dir + i * ps_r * col_dir = 0
    # Two equations using x and y patient components (z is slice-position).
    # We project onto the 2D image plane.
    A = np.array([
        [g.pixel_spacing_col_mm * row_dir[0], g.pixel_spacing_row_mm * col_dir[0]],
        [g.pixel_spacing_col_mm * row_dir[1], g.pixel_spacing_row_mm * col_dir[1]],
    ])
    b = np.array([-g.ipp_x, -g.ipp_y])
    try:
        sol, *_ = np.linalg.lstsq(A, b, rcond=None)
        j, i = float(sol[0]), float(sol[1])
        # Only record if it lands inside the slice
        if 0 <= i < H and 0 <= j < W:
            g.pc_pixel_row = i
            g.pc_pixel_col = j
    except np.linalg.LinAlgError:
        pass

    # Orientation alignment: classify by the slice-normal direction.
    # slice_normal = row_dir × col_dir. Its dominant patient-axis tells us
    # the slice plane:
    #   |normal·x| ≈ 1  → sagittal slice (normal points along patient L/R)
    #   |normal·y| ≈ 1  → coronal slice  (normal points along patient A/P)
    #   |normal·z| ≈ 1  → axial slice    (normal points along patient S/I)
    normal = np.cross(np.array(row_dir), np.array(col_dir))
    g.orientation_axial_alignment    = float(abs(normal[2]))  # along z
    g.orientation_sagittal_alignment = float(abs(normal[0]))  # along x
    return g


def extract_slice_facts(entry: FileEntry) -> SliceFacts:
    """Open a single imaging file and compute its facts.

    Returns a SliceFacts with status set appropriately. Never raises.
    """
    sf = SliceFacts(
        extracted_path=entry.extraction.extracted_path,
        sop_instance_uid=entry.headers.sop_instance_uid or "" if entry.headers else "",
        series_instance_uid=entry.headers.series_instance_uid or "" if entry.headers else "",
        series_description=entry.headers.series_description if entry.headers else None,
        modality=entry.headers.modality if entry.headers else None,
        instance_number=entry.headers.instance_number if entry.headers else None,
        z_position_mm=(entry.headers.image_position_patient[2]
                        if (entry.headers and entry.headers.image_position_patient
                            and len(entry.headers.image_position_patient) >= 3)
                        else None),
    )

    if not entry.headers or not entry.headers.is_imaging_modality:
        sf.status = 'NOT_IMAGING'
        sf.status_detail = f'modality={entry.headers.modality if entry.headers else None}'
        return sf

    # Open the pixel data
    try:
        ds = pydicom.dcmread(entry.extraction.extracted_path, force=True)
        img = ds.pixel_array
    except Exception as e:
        sf.status = 'PIXEL_READ_FAILED'
        sf.status_detail = f'{type(e).__name__}: {e}'[:200]
        return sf

    img = np.asarray(img, dtype=np.float32)
    if img.ndim == 3:
        # Multi-frame DICOM: take the first frame
        img = img[0]
    if img.ndim != 2 or img.size == 0:
        sf.status = 'UNUSABLE_SHAPE'
        sf.status_detail = f'shape={img.shape}'
        return sf

    # Apply rescale slope/intercept if present (CT only typically, but
    # general-safe to apply since defaults are slope=1 intercept=0).
    slope = float(getattr(ds, 'RescaleSlope', 1.0) or 1.0)
    intercept = float(getattr(ds, 'RescaleIntercept', 0.0) or 0.0)
    if slope != 1.0 or intercept != 0.0:
        img = img * slope + intercept

    # Geometry
    geometry = _compute_geometry_facts(ds, img.shape)
    sf.geometry = geometry

    # Intensity
    intensity = _compute_intensity_stats(img)
    sf.intensity = intensity

    # k-space bands (use the smaller pixel spacing)
    ps_mm = min(geometry.pixel_spacing_row_mm or 1.0,
                geometry.pixel_spacing_col_mm or 1.0)
    if ps_mm <= 0:
        ps_mm = 1.0
    sf.kspace = _compute_kspace_bands(img, ps_mm)

    # Gradient summary
    sf.gradient = _compute_gradient_facts(img)

    # Per-band object counts
    sf.band_objects = _compute_band_object_counts(img, intensity, ps_mm)

    return sf


# ════════════════════════════════════════════════════════════════════════════
# SERIES-LEVEL AGGREGATION
# ════════════════════════════════════════════════════════════════════════════

def _aggregate_series(
    slice_facts: list[SliceFacts],
    series_index: list[SeriesEntry],
) -> list[SeriesFacts]:
    """Build SeriesFacts by grouping SliceFacts on series_instance_uid."""
    by_uid: dict[str, list[SliceFacts]] = {}
    for sf in slice_facts:
        by_uid.setdefault(sf.series_instance_uid, []).append(sf)

    out: list[SeriesFacts] = []
    for entry in series_index:
        uid = entry.series_instance_uid
        members = by_uid.get(uid, [])
        ok_members = [m for m in members if m.status == 'OK']

        sf_out = SeriesFacts(
            series_instance_uid=uid,
            series_description=entry.series_description,
            modality=entry.modality,
            n_slices_imaging=len(ok_members),
            n_slices_unusable=len(members) - len(ok_members),
        )

        if ok_members:
            first = ok_members[0]
            if first.geometry:
                sf_out.rows = first.geometry.rows
                sf_out.cols = first.geometry.cols
                sf_out.pixel_spacing_mm = min(
                    first.geometry.pixel_spacing_row_mm,
                    first.geometry.pixel_spacing_col_mm
                )
            z_vals = [m.z_position_mm for m in ok_members if m.z_position_mm is not None]
            if z_vals:
                sf_out.z_min = float(min(z_vals))
                sf_out.z_max = float(max(z_vals))
                sf_out.z_span_mm = float(sf_out.z_max - sf_out.z_min)

            p50s = [m.intensity.p50 for m in ok_members if m.intensity]
            p90s = [m.intensity.p90 for m in ok_members if m.intensity]
            if p50s:
                sf_out.stack_p50_median = float(np.median(p50s))
            if p90s:
                sf_out.stack_p90_median = float(np.median(p90s))

            # Stack orientation: majority vote from geometry alignment
            n_axial = sum(1 for m in ok_members
                          if m.geometry and m.geometry.orientation_axial_alignment > 0.85)
            n_sag = sum(1 for m in ok_members
                        if m.geometry and m.geometry.orientation_sagittal_alignment > 0.85)
            n_cor = len(ok_members) - n_axial - n_sag
            if n_axial > len(ok_members) * 0.7:
                sf_out.is_axial_stack = True
            elif n_sag > len(ok_members) * 0.7:
                sf_out.is_sagittal_stack = True
            elif n_cor > len(ok_members) * 0.7:
                sf_out.is_coronal_stack = True

        out.append(sf_out)
    return out


# ════════════════════════════════════════════════════════════════════════════
# TOP-LEVEL RUN
# ════════════════════════════════════════════════════════════════════════════

def run(manifest: Manifest, write_json: bool = True) -> ExtractionResult:
    """Run the data extraction layer on an lzw Manifest.

    Args:
        manifest:    output of lzw.walk()
        write_json:  if True, also write extraction.json into manifest.work_dir

    Returns an ExtractionResult.
    """
    t0 = time.time()
    result = ExtractionResult(work_dir=manifest.work_dir)

    # Only run on imaging files
    imaging_files = [
        e for e in manifest.files
        if e.headers and e.headers.is_imaging_modality
    ]
    log.info('Extracting %d imaging files (of %d total) ...',
             len(imaging_files), len(manifest.files))

    for i, entry in enumerate(imaging_files):
        sf = extract_slice_facts(entry)
        result.slices.append(sf)
        if sf.status != 'OK':
            result.n_slices_unusable += 1

    result.n_slice_facts = len(result.slices)

    # Aggregate per series
    result.series = _aggregate_series(result.slices, manifest.series_index)
    result.n_series_facts = len(result.series)

    result.elapsed_seconds = time.time() - t0

    if write_json and manifest.work_dir:
        out = Path(manifest.work_dir) / 'extraction.json'
        out.write_text(json.dumps(asdict(result), indent=2, default=str))
        log.info('Wrote extraction.json: %s', out)

    return result


# ════════════════════════════════════════════════════════════════════════════
# FLAT TABLE EXPORTS — for downstream consumption
# ════════════════════════════════════════════════════════════════════════════

def slice_facts_to_rows(slices: list[SliceFacts]) -> list[dict]:
    """Flatten SliceFacts into one dict per slice, with all numeric facts."""
    rows = []
    for sf in slices:
        row = {
            'extracted_path':       sf.extracted_path,
            'sop_instance_uid':     sf.sop_instance_uid,
            'series_instance_uid':  sf.series_instance_uid,
            'series_description':   sf.series_description,
            'modality':             sf.modality,
            'instance_number':      sf.instance_number,
            'z_position_mm':        sf.z_position_mm,
            'status':               sf.status,
            'status_detail':        sf.status_detail,
        }
        if sf.geometry:
            row.update({
                'rows':                  sf.geometry.rows,
                'cols':                  sf.geometry.cols,
                'pixel_spacing_row_mm':  sf.geometry.pixel_spacing_row_mm,
                'pixel_spacing_col_mm':  sf.geometry.pixel_spacing_col_mm,
                'slice_thickness_mm':    sf.geometry.slice_thickness_mm,
                'ipp_x': sf.geometry.ipp_x,
                'ipp_y': sf.geometry.ipp_y,
                'ipp_z': sf.geometry.ipp_z,
                'center_x':            sf.geometry.center_xyz[0] if sf.geometry.center_xyz else None,
                'center_y':            sf.geometry.center_xyz[1] if sf.geometry.center_xyz else None,
                'center_z':            sf.geometry.center_xyz[2] if sf.geometry.center_xyz else None,
                'pc_pixel_row':        sf.geometry.pc_pixel_row,
                'pc_pixel_col':        sf.geometry.pc_pixel_col,
                'orient_axial_align':  sf.geometry.orientation_axial_alignment,
                'orient_sag_align':    sf.geometry.orientation_sagittal_alignment,
            })
        if sf.intensity:
            row.update({
                'i_min':    sf.intensity.min,
                'i_max':    sf.intensity.max,
                'i_mean':   sf.intensity.mean,
                'i_median': sf.intensity.median,
                'i_std':    sf.intensity.std,
                'i_p05':    sf.intensity.p05,
                'i_p25':    sf.intensity.p25,
                'i_p50':    sf.intensity.p50,
                'i_p75':    sf.intensity.p75,
                'i_p90':    sf.intensity.p90,
                'i_p95':    sf.intensity.p95,
                'i_p99':    sf.intensity.p99,
            })
        if sf.kspace:
            row.update({
                'k_total_ex_dc':     sf.kspace.total_energy_ex_dc,
                'k_e_noise_subpix':  sf.kspace.e_noise_subpix,
                'k_e_noise_voxel':   sf.kspace.e_noise_voxel,
                'k_e_fine_anatomy':  sf.kspace.e_fine_anatomy,
                'k_e_cord_scale':    sf.kspace.e_cord_scale,
                'k_e_vertebra_scale':sf.kspace.e_vertebra_scale,
                'k_e_body_shape':    sf.kspace.e_body_shape,
            })
        if sf.gradient:
            row.update({
                'g_mean':           sf.gradient.gmag_mean,
                'g_p95':            sf.gradient.gmag_p95,
                'g_p99':            sf.gradient.gmag_p99,
                'g_peak_angle_deg': sf.gradient.peak_angle_deg,
                'g_n_strong':       sf.gradient.n_strong,
            })
        if sf.band_objects:
            row.update({
                'obj_n_dark':              sf.band_objects.n_dark,
                'obj_n_medium':            sf.band_objects.n_medium,
                'obj_n_bright':            sf.band_objects.n_bright,
                'obj_n_very_bright':       sf.band_objects.n_very_bright,
                'obj_biggest_dark_mm2':    sf.band_objects.biggest_dark_mm2,
                'obj_biggest_medium_mm2':  sf.band_objects.biggest_medium_mm2,
                'obj_biggest_bright_mm2':  sf.band_objects.biggest_bright_mm2,
                'obj_biggest_very_bright_mm2': sf.band_objects.biggest_very_bright_mm2,
            })
        rows.append(row)
    return rows


def series_facts_to_rows(series: list[SeriesFacts]) -> list[dict]:
    return [asdict(s) for s in series]


def write_csv(rows: list[dict], path: str | Path) -> None:
    """Write rows to a CSV. Empty list = empty CSV with no header."""
    import csv
    path = Path(path)
    if not rows:
        path.write_text('')
        return
    # Union of all keys, preserving first-seen order
    all_keys: list[str] = []
    seen = set()
    for r in rows:
        for k in r.keys():
            if k not in seen:
                seen.add(k)
                all_keys.append(k)
    with open(path, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=all_keys)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, '') for k in all_keys})


# ════════════════════════════════════════════════════════════════════════════
# CLI
# ════════════════════════════════════════════════════════════════════════════

def _main():
    import argparse
    import lzw

    p = argparse.ArgumentParser(description='Data extraction layer: pixel-level facts from a Manifest.')
    p.add_argument('input', help='zip, directory, or single DICOM file')
    p.add_argument('--work-dir', default=None,
                   help='where to extract (default: temp dir)')
    p.add_argument('--csv-out', default=None,
                   help='write SliceFacts table to this CSV path')
    p.add_argument('--series-csv-out', default=None,
                   help='write SeriesFacts table to this CSV path')
    p.add_argument('--no-json', action='store_true',
                   help="don't write extraction.json into work_dir")
    p.add_argument('--quiet', action='store_true')
    args = p.parse_args()

    if not args.quiet:
        logging.basicConfig(level=logging.INFO, format='%(message)s')

    # Stage 1: walk (LZW)
    manifest = lzw.walk(args.input, work_dir=args.work_dir, write_manifest=True)
    if manifest.status != 'OK':
        print(f'LZW status: {manifest.status}: {manifest.status_detail}')

    # Stage 2: extract
    result = run(manifest, write_json=(not args.no_json))

    print(f'Extracted {result.n_slice_facts} slice facts '
          f'({result.n_slices_unusable} unusable) in {result.elapsed_seconds:.1f}s')
    print(f'Aggregated {result.n_series_facts} series facts')

    if args.csv_out:
        rows = slice_facts_to_rows(result.slices)
        write_csv(rows, args.csv_out)
        print(f'Wrote SliceFacts CSV: {args.csv_out}')
    if args.series_csv_out:
        rows = series_facts_to_rows(result.series)
        write_csv(rows, args.series_csv_out)
        print(f'Wrote SeriesFacts CSV: {args.series_csv_out}')


if __name__ == '__main__':
    _main()
